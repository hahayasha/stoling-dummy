# Banking App

#### This Design is implemented in Flutter and the video is live [here](https://youtu.be/kx8mHkTY6YA)

#### Flutter App UI implementation inspired from a [design](https://dribbble.com/shots/10514903--Freebie-Finance-Mobile-Application-Exploration) on Dribbble by deisgner [Kevinduk](https://dribbble.com/Kevinduk)

# The Design


![Alt text](/design.png)
# The Flutter App
| ![Alt text](/Screenshot1.png) | ![Alt text](Screenshot2.png) |
| ------------- | ------------- |

# Youtube Video
![Alt text](/Thumbnail.png)
#### This Design is implemented in Flutter and the video is live [here](https://youtu.be/kx8mHkTY6YA)