package com.example.discounttour

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
