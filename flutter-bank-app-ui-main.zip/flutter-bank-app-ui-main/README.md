# Flutter Bank App UI

![Tumb - Github](https://user-images.githubusercontent.com/37796466/187327307-c98f532a-2635-407e-8469-e2e94cbd8699.png)
