package com.example.flutter_ui_bank_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
