# Flutter Chat App UI

![chat](https://user-images.githubusercontent.com/37796466/112643647-294b8680-8e77-11eb-9137-2f7cc5c050d2.png)

