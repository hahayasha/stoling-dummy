# Flutter Plant Shop UI

![Capture 1](https://user-images.githubusercontent.com/37796466/113430817-06841980-9405-11eb-8ef4-fa0e910babcd.PNG)
![Capture 2](https://user-images.githubusercontent.com/37796466/113430810-02f09280-9405-11eb-98e2-99c9d8feaa4a.PNG)

