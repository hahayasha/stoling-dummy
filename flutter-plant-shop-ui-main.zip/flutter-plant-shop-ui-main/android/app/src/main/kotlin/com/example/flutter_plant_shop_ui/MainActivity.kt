package com.example.flutter_plant_shop_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
