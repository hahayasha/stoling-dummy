# Flutter Point Of Sale App UI

![Tumb - Github](https://user-images.githubusercontent.com/37796466/198330351-c51faaca-e14d-415d-971c-cd1f4d081a2e.png)
