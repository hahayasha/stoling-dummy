class BookModel{

  String imgAssetPath;
  String title;
  String description;
  String categorie;
  int rating;

  BookModel({this.title,this.description,this.categorie,this.rating, this.imgAssetPath});
}