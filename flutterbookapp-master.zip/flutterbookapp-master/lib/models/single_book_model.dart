class SingleBookModel{

  String imgAssetPath;
  String title;
  String categorie;

  SingleBookModel({this.imgAssetPath,this.title,
  this.categorie});

}