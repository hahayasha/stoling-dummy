import 'package:flutter/material.dart';

Color darkGreen = Color(0xff007084);
Color greyColor = Color(0xffBDC3C7);