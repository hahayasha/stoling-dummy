class CategorieModel{

  String categorieName;
  String imgAssetPath;
  String color1;
  String color2;

  CategorieModel({this.categorieName,this.imgAssetPath,this.color1,this.color2});
}
