class ProductModel{

  int priceInDollars;
  String productName;
  int rating;
  String imgUrl;
  int noOfRating;

  ProductModel({this.productName,this.imgUrl,this.priceInDollars,this.rating,this.noOfRating});
}