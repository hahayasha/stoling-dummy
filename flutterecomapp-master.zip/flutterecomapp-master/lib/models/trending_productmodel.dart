class TrendingProductModel{

  String productName;
  String storename;
  String imgUrl;
  int noOfRating;
  int priceInDollars;
  int rating;

  TrendingProductModel({this.imgUrl,this.noOfRating,this
  .priceInDollars,this.productName,this.storename, this.rating});

}