import 'package:flutter/material.dart';

Color textGrey = Color(0xff9B9B9B);