![Flutter Chat App UI Design Made by theindianappguy](https://user-images.githubusercontent.com/55942632/81511537-b8bb7a00-9337-11ea-8c1e-365d02f44092.png)

<p >
  <a href="https://github.com/theindianappguy/messages">
    <img src="https://img.shields.io/github/stars/theindianappguy/messages?style=for-the-badge" alt="Total downloads on GitHub." /></a>
<a href="https://www.linkedin.com/in/lamsanskar/">
    <img src="https://img.shields.io/badge/Support-Recommed%2FEndorse%20me%20on%20Linkedin-yellow?style=for-the-badge&logo=linkedin" alt="Recommend me on LinkedIn" /></a>

</p>

Chat App UI made with Flutter, Hosted on Codemagic. Don't forget to star ⭐  the repo it motivates me to share more open source
Design Credits [Message](https://dribbble.com/shots/6499682-messages)

### Created & Maintained By

[Sanskar Tiwari](https://github.com/theindianappguy) ([@theindianappguy](https://twitter.com/Theindianappguy)) ([YouTube](https://www.youtube.com/c/SanskarTiwari))

> 
>
> - [PayPal](https://paypal.me/iamsanskartiwari)

### License

    Copyright 2020 Sanskar Tiwari

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.


