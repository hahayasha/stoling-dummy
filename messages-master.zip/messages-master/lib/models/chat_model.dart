class ChatModel {
  String imgUrl;
  String name;
  String lastMessage;
  bool haveunreadmessages;
  int unreadmessages;
  String lastSeenTime;
}
