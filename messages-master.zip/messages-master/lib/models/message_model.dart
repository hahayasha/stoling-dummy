class MessageModel {
  String message;
  bool isByme;
}
