class StoryModel {
  String imgUrl;
  String username;
}
